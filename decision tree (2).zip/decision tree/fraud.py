# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 14:38:22 2020

@author: AAYUSH VOHRA
"""
#importing necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("G:/practical data science/Assignments/decision tree/Fraud_check.csv")
df.head()
df=pd.get_dummies(df,columns=['Undergrad','Marital.Status','Urban'], drop_first=True)
df["TaxInc"] = pd.cut(df["Taxable.Income"], bins = [10002,30000,99620], labels = ["Risky", "Good"])
df = pd.get_dummies(df,columns = ["TaxInc"],drop_first=True)
df.tail(10)
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)
df_norm = norm_func(df.iloc[:,1:])
df_norm.tail(10)
colnames = list(df.columns)
predictors = colnames[1:7]
predictors
target = colnames[7]
target
import numpy as np
from sklearn.model_selection import train_test_split
train,test = train_test_split(df,test_size = 0.2)
from sklearn.tree import  DecisionTreeClassifier
model = DecisionTreeClassifier(criterion = 'entropy')
model.fit(train[predictors],train[target])
preds = model.predict(test[predictors])
preds
type(preds)
pd.Series(preds).value_counts()
np.mean(preds==test.TaxInc_Good)
