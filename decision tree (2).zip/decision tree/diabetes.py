# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 14:21:52 2020

@author: AAYUSH VOHRA
"""
import pandas as pd
import numpy as np
# Reading the Diabetes Data #################
Diabetes = pd.read_csv("G:/practical data science/Assignments/decision tree/Diabetes.csv")
Diabetes.head()
Diabetes.columns
colnames = list(Diabetes.columns)
colnames 
predictors = colnames[:8]
predictors
target = colnames[8]
target
X = Diabetes[predictors]
Y = Diabetes[target]
X
###### GridSearch 
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(n_jobs=2,oob_score=True,n_estimators=1000,criterion="entropy")
np.shape(Diabetes) 
rf.fit(X,Y)
rf.estimators_
rf.classes_
rf.n_classes_
rf.n_features_
rf.n_outputs_
rf.predict(X)
Diabetes['rf_pred'] = rf.predict(X)
from sklearn.metrics import confusion_matrix
confusion_matrix(Diabetes['Outcome'],Diabetes['rf_pred'])
Diabetes["rf_pred"]
