# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 15:44:10 2020

@author: AAYUSH VOHRA
"""
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv("G:/practical data science/Assignments/decision tree/Company_Data.csv")
data.head()
data['US'].unique()
data.US.value_counts()
colnames = list(data.columns)
colnames
predictors = colnames[0:4]
predictors
target = colnames[4]
target
import numpy as np
from sklearn.model_selection import train_test_split
train,test = train_test_split(data,test_size = 0.2)
from sklearn.tree import  DecisionTreeClassifier
model = DecisionTreeClassifier(criterion = 'entropy')
model.fit(train[predictors],train[target])
preds = model.predict(test[predictors])
preds
type(preds)
pd.Series(preds).value_counts()
pd.crosstab(test[target],preds)
np.mean(preds==test.US)
